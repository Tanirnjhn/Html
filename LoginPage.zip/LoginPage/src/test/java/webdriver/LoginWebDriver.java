package webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginWebDriver {
	
	static WebDriver driver;
	
	public static void main(String args[]) throws InterruptedException {
	
		System.setProperty("webdriver.chrome.driver","D:\\Users\\TANAGRAW\\Desktop\\taneesha\\module 3\\chromedriver_win32\\chromedriver.exe");
	    driver=new ChromeDriver();
	    driver.get("file:///D:/Users/TANAGRAW/Desktop/taneesha/module%203/login.html");
	
	    //title
	    
	    String title=driver.getTitle();
		if(title.contentEquals("")) 
		    System.out.println("****** Title Matched");
		else 
			System.out.println("****** Title NOT Matched");
		
		// all data 
		
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		Thread.sleep(1000);
		driver.findElement(By.name("userPwd")).sendKeys("capg1234");
	    Thread.sleep(1000);
	    driver.findElement(By.className("btn")).click();
	   
	   driver.navigate().to("file:///D:/Users/TANAGRAW/Desktop/taneesha/module%203/hotelbooking.html");
	   Thread.sleep(1000);
		driver.navigate().back();
	
	//username blank
		driver.findElement(By.name("userName")).clear();
	driver.findElement(By.name("userName")).sendKeys("");
	Thread.sleep(1000);
	driver.findElement(By.name("userPwd")).clear();
	driver.findElement(By.name("userPwd")).sendKeys("capg1234");
    Thread.sleep(1000);
    driver.findElement(By.className("btn")).click();
    
   String userAlert=driver.findElement(By.id("userErrMsg")).getText();
	Thread.sleep(1000);
	System.out.println("**************"+ userAlert);
   
   // paswword blank
	driver.findElement(By.name("userName")).clear();
   driver.findElement(By.name("userName")).sendKeys("capgemini");
	Thread.sleep(1000);
	driver.findElement(By.name("userPwd")).clear();
	driver.findElement(By.name("userPwd")).sendKeys("");
   Thread.sleep(1000);
   driver.findElement(By.className("btn")).click();
   
  String pwdAlert=driver.findElement(By.id("pwdErrMsg")).getText();
	Thread.sleep(1000);
	System.out.println("**************"+ pwdAlert);

  
  //inccorect user name nd password
  
	driver.findElement(By.name("userName")).clear();
	driver.findElement(By.name("userName")).sendKeys("rfg");
	Thread.sleep(1000);
	driver.findElement(By.name("userPwd")).clear();
	driver.findElement(By.name("userPwd")).sendKeys("capg12");
  Thread.sleep(1000);
 driver.findElement(By.className("btn")).click();
 callAlert();
	}
	
	
	public static void callAlert()
	{
		String alertMessage=driver.switchTo().alert().getText();
		System.out.println(alertMessage);
		driver.switchTo().alert().accept();
	}
}
